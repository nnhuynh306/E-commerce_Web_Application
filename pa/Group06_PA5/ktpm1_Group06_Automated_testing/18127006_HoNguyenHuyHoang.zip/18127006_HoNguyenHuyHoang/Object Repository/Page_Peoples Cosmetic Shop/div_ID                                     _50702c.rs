<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_ID                                     _50702c</name>
   <tag></tag>
   <elementGuidId>6a413f91-cb41-48f1-bb1d-3548d21007a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='v-pills-add-product']/div/div/form/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#v-pills-add-product > div.container.p-4 > div.container > form > div.row.pb-3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>row pb-3</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                            
                                                
                                                    
                                                        ID
                                                    
                                                    
                                                        
                                                    
                                                    
                                                        Tên sản phẩm
                                                    
                                                    
                                                        
                                                    
                                                    
                                                        Số Lượng
                                                    
                                                    
                                                        
                                                    
                                                    
                                                        Giá
                                                    
                                                    
                                                        
                                                    
                                                    
                                                        Mã phân loại
                                                    
                                                    
                                                        
                                                    
                                                     
                                                        Tên phân loại
                                                    
                                                    
                                                        
                                                    
                                                    
                                                        Mô tả
                                                    
                                                    
                                                        
                                                    
                                                    
                                                        Hình nhỏ
                                                    
                                                    
                                                        
                                                        

                                                        
                                                            
                                                        
                                                    
                                                    
                                                        Hình lớn
                                                    
                                                    
                                                        
                                                        

                                                        
                                                            
                                                        
                                                    
                                                
                                            
                                            
                                                Thêm mới sản phẩm
                                            
                                        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;v-pills-add-product&quot;)/div[@class=&quot;container p-4&quot;]/div[@class=&quot;container&quot;]/form[1]/div[@class=&quot;row pb-3&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='v-pills-add-product']/div/div/form/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thêm sản phẩm'])[2]/following::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cập nhật'])[1]/following::div[6]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div/form/div</value>
   </webElementXpaths>
</WebElementEntity>
