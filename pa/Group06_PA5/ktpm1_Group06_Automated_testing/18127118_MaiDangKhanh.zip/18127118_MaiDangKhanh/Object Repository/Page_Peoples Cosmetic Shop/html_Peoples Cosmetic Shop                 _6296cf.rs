<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>html_Peoples Cosmetic Shop                 _6296cf</name>
   <tag></tag>
   <elementGuidId>67ef0614-683a-4ca6-9d9a-e491da4d3487</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>html</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>html</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>lang</name>
      <type>Main</type>
      <value>en</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
    
    
    People's Cosmetic Shop
    
    
    
    
    
    
     
    
    
    
    
    
    
    
    
    
    
    
    
    
#katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}

        
            
                
                    
                        
                            Đăng nhập
                            Đăng ký
                        
                    
                
            
        
    
        
            
              
                    
                      
                        
                          
                          
                        
                      
                    
                    
                        
                            Nước hoa
                            Mỹ phẩm
                        
                        
                        
                            Thời trang
                            Chăm sóc da
                        
                    
                    
                        
                            0
                        
                        
                            
                            
                            
                        
                    
                
            
            
        
            
                
                    
                        
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                    
                                        
                                        
                                            Home
                                            Tài khoản
                                            
                                                
                                                    
                                                        Đăng nhập
                                                        Đăng ký
                                                    
                                                
                                            
                                            Shop
                                                
                                                    
                                                        Tất cả sản phẩm
                                                        Nước hoa
                                                        Mỹ phẩm
                                                        Thời trang
                                                        Chăm sóc da
                                                    
                                                    
                                                        Giỏ hàng
                                                        Thanh toán
                                                    
                                                
                                            
                                        
                                    
                                    
                                        
                                            
                                            
                                             
                                        
                                    
                                
                            
                        
                    
                
            
        
    
    
        ĐĂNG NHẬP
        
          
            Mật khẩu sai
            
                 Tên đăng nhập hoặc Email: 
                
            
            
                 Mật khẩu: 
                
            
            
                Đăng ký
            
            
                Lấy lại mật khẩu
            
            
                Đăng nhập
            
          
        
      

    
        
        
        
        
        
        
    
        
            
                
                    
                    
                        
                            
                                
                                
                                 
                            
                        
                    
                
                
                    
                        
                            
                                Thông tin liên lạc
                                Địa chỉ:227 Nguyễn Văn Cừ, phường 4, quận 5, Thành phố Hồ Chí Minh
                                Số điện thoại:+84 28 6288 4499
                                Email:Group6@student.hcmus.edu.vn
                                Giờ mở cửa:9.00am - 10.00.pm
                            
                        
                        
                            
                                Phương thức thanh toán linh hoạt, thuận tiện
                                Chúng tôi chấp nhận
                                
                            
                        
                    
                
            
        
    
    
        
            
                Base on Eliah©
            
        /html[1]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//html</value>
   </webElementXpaths>
</WebElementEntity>
