<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Sort</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>568e9401-6901-4e5e-a852-3453ce115bb1</testSuiteGuid>
   <testCaseLink>
      <guid>18ef6140-5e15-4517-aae0-4c5be71b4c20</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sort/SortbyName(AtoZ)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>56e38f83-7837-437a-a37d-4b602e195b68</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sort/SortbyName(ZtoA)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3c546ec3-3f25-467f-9efd-f41557641e83</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sort/SortbyPrice(HighToLow)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>903fc956-3b57-4740-94d8-afa3d432731b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sort/SortbyPrice(LowToHigh)</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
