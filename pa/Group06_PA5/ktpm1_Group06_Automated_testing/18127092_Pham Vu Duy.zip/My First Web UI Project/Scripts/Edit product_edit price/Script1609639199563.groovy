import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://dangcompany.herokuapp.com/')

WebUI.click(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/a_ng nhp'))

WebUI.setText(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/input_Tn ng nhp hoc Email_username'), 'admin')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/input_Mt khu_password'), '6Nqb8H5yrfH5bM1DJp2E3w==')

WebUI.click(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/button_ng nhp'))

WebUI.click(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/a_Admin Manager'))

WebUI.click(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/input_ID_product_id'))

WebUI.setText(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/input_ID_product_id'), '2')

WebUI.click(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/button_Tm thng tin'))

WebUI.setText(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/input_Gi_price_result'), '900000')

WebUI.click(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/button_Cp nht'))

WebUI.click(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/img'))

WebUI.click(findTestObject('Object Repository/Page_Peoples Cosmetic Shop/img_1'))

