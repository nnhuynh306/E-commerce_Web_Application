<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_ng nhp                            ng k_9af5a0</name>
   <tag></tag>
   <elementGuidId>71d5d394-fe30-4c8e-ae60-9457c7360e9d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
                
                    
                        
                            Đăng nhập
                            Đăng ký
                        
                    
                
            
        
    
        
            
              
                    
                      
                        
                          
                          
                        
                      
                    
                    
                        
                            Nước hoa
                            Mỹ phẩm
                        
                        
                        
                            Thời trang
                            Chăm sóc da
                        
                    
                    
                        
                            0
                        
                        
                            
                            
                            
                        
                    
                
            
            
        
            
                
                    
                        
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                    
                                        
                                        
                                            Home
                                            Tài khoản
                                            
                                                
                                                    
                                                        Đăng nhập
                                                        Đăng ký
                                                    
                                                
                                            
                                            Shop
                                                
                                                    
                                                        Tất cả sản phẩm
                                                        Nước hoa
                                                        Mỹ phẩm
                                                        Thời trang
                                                        Chăm sóc da
                                                    
                                                    
                                                        Giỏ hàng
                                                        Thanh toán
                                                    
                                                
                                            
                                        
                                    
                                    
                                        
                                            
                                            
                                             
                                        
                                    
                                
                            
                        
                    
                
            
        
    
      
        
          
            
              
                
                  
                  
                  
                  
                
                
                  
                  
                  
                  
                
              

  
            
            
              
                    
                      
                          Nước hoa
                        212 Sexy Men
                      
                      $110
                      
                      
                        
                          Nhãn hiệu: Carolina Herrera
                          Mã sản phẩm: 3
                          Hàng tồn: 10
                        
                           
                          
                          
                              
                                  
                              
                                                        

                          
                  
                        
                        
                        
                        
                          
                            Mô tả
                          
                          
                            
                              212 Sexy Men được cho ra mắt vào năm 2006, sở hữu một hương thơm nồng ấm, gợi cảm và tinh tế được sáng chế tác hai nhà sáng chế nước hoa là Alberto Morillas và Rosendo Mateu. Hương thơm 212 Sexy Men thể hiện hình mẫu các chàng trai thành thị sành điệu và rất biết cách thể hiện mình, đặc biệt muốn tạo ấn tượng và thể hiện sức quyến rũ đối với nữ giới. Đây là một hương thơm gợi cảm, tươi mát theo xu hướng phương Đông. Carolina Herrera nói rằng bà đã lấy cảm hứng cho loại nước hoa này bằng cách pha trộn giữa phong cách hiện đại của thành phố New York và những đêm phương Đông huyền bí. Hương thơm từ bạch đậu khấu, hồ tiêu và hổ phách được kết hợp một cách tinh tế ở lớp hương đầu gợi ý lên cảnh tượng tuyệt đẹp trong một nhà hàng Ấn sang trọng, nơi hương cà ri phảng phất thơm nồng. Và rất nhanh chóng, Hương Va ni như một khu rừng huyền bí sẽ làm dịu đi lớp hương đầu tạo nên một 212 Sexy men đầy mạnh mẽ nhưng cũng rất ngọt ngào. Giờ đây khi lớp hương đầu đã lùi về phía sau để làm nên, sẽ chỉ còn lại mùi gỗ thơm ngát, hương hổ phách nồng ấm, mùi quýt tươi và phản phất đâu đó một chút hương hoa nhẹ nhàng quyến rũ. Mọi hương thơm được kết hợp một cách tinh tế hài hòa, đặc biệt nếu như so với các dòng nước hoa Va ni khác thì 212 Sexy Men thật sự đã làm tốt hơn rất nhiều để đem lại một mùi hương Va ni đầy quyến rũ và mạnh mẽ. Tương tự như hương thơm đặc trưng, thiết kế chai cũng mang lại sự tinh tế đầy nam tính. Đặc biệt sự kết hợp tinh tế trong thiết kế bằng kim loại với cách đóng và mở nắp chai cũng làm toát lên sự rắn chắc và mạnh mẽ.212 Sexy Men sẽ là dòng nước hoa lý tưởng mà bất kỳ người đàn ông hiện đại nào cũng ao ước bổ sung vào bộ sưu tập của mình. Với hương thơm từ quýt tươi, gỗ ấm hứa hẹn sẽ là sự lựa chọn hoàn hảo để sử dụng ở bất kỳ dịp nào
                            
                          
                        
                      
                    
              
            
          
        
  
      
    






 
     
			
				
				
					
						
							admin
							2020-12-21
						
						
              
                      
                
							Normal
						
					
				
			
		
     
			
				
				
					
						
							duyphamvu47
							2021-01-03
						
						
              
                          
                
							This is a test comment
						
					
				
			
		
 

    
        
        
        
        
        
        
    
        
            
                
                    
                    
                        
                            
                                
                                
                                 
                            
                        
                    
                
                
                    
                        
                            
                                Thông tin liên lạc
                                Địa chỉ:227 Nguyễn Văn Cừ, phường 4, quận 5, Thành phố Hồ Chí Minh
                                Số điện thoại:+84 28 6288 4499
                                Email:Group6@student.hcmus.edu.vn
                                Giờ mở cửa:9.00am - 10.00.pm
                            
                        
                        
                            
                                Phương thức thanh toán linh hoạt, thuận tiện
                                Chúng tôi chấp nhận
                                
                            
                        
                    
                
            
        
    
    
        
            
                Base on Eliah©
            
        /html[1]/body[1]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
   </webElementXpaths>
</WebElementEntity>
