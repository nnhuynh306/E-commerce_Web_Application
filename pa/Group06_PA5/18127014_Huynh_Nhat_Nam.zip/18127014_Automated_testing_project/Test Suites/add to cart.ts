<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>add to cart</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>48028c04-27b4-498d-af84-246e93fc24d0</testSuiteGuid>
   <testCaseLink>
      <guid>87981fe5-16e0-465b-9c75-1c9d3eb2c4fe</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Add to cart/Add product to cart when logged in</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3e8e5f9c-eeb2-45b1-8e2a-1b0268df6217</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Add to cart/Add product to cart when not logged in</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>5f409773-b0f2-48cc-9255-e0479629352f</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
